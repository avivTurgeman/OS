#ifndef ASSIGNMENT_5_PART_A_H
#define ASSIGNMENT_5_PART_A_H
#include <math.h>
int isPrime(unsigned int num);
#endif //ASSIGNMENT_5_PART_A_H
