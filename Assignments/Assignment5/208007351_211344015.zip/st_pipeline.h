#ifndef ASSIGNMENT_5_ST_PIPELINE_H
#define ASSIGNMENT_5_ST_PIPELINE_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "Part_C.h"
#include "Part_A.h"
#include <unistd.h>

#define TRUE 1

int generateRandomNumber();
void func4(int num,pparam p);
void func3(int num,pparam p);
void func2(int num,pparam p);
void func1(int num,pparam p);

#endif //ASSIGNMENT_5_ST_PIPELINE_H



