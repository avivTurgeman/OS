submitted by: Aviv Turgeman 208007351 AND Alon Suissa 211344015

OS Assignment 4 usage:
	first we will compile the file with the command 'make'
	second, we will open few terminals.
	on the first one we will run the server with the command './react_server'.
	on the other terminals we will run the clients provided by the STAFF.
	
	NOTE: the client.c file is not provided in the submission zip
	
	
note that we used based code from few sources:
	-beej select-server: https://beej.us/guide/bgnet/examples/selectserver.c 
	-geeks for geeks hash: https://www.geeksforgeeks.org/implementation-of-hash-table-in-c-using-separate-chaining/ 
	-chatGPT: asked it: i want to clean up allocated space before canceling my thread.
	

